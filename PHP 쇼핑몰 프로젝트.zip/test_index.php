<?
	echo "Hello!";
?>